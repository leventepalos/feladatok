﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kétváltozoközülanyagyobb
{
    class Program
    {
        static void Main(string[] args)
        {

            int szam1 = 11;
            int szam2 = 10;

            if (szam1 = szam2 || szam1 < szam2)
            {
                Console.WriteLine("A nagyobbik szam a:" + szam2);
            }
            

            else if(szam1 > szam2)
            {
                Console.WriteLine("A nagyobbik szam a:" + szam1);
            }
                
            else
            {
                Console.WriteLine("A két szam egyenlő");
            }


            Console.ReadLine();
        }
    }
}
