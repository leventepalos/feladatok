﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace épitményadó
{
    internal class Program
    {
        
class Telek
        {
            public string Utca { get; set; }
            public string Hazszam { get; set; }
            public string Tipus { get; set; }
            public int Meret { get; set; }
            public string Adoszam { get; set; }

            public Telek(string utca, string hazszam, string tipus, int meret, string adoszam)
            {
                Utca = utca;
                Hazszam = hazszam;
                Tipus = tipus;
                Meret = meret;
                Adoszam = adoszam;
            }
        }

        class épitményadó
        {
            static void Main()
            {
               
                List<Telek> telekLista = new List<Telek>();

                try
                {
                    
                    string[] sorok = File.ReadAllLines("utca.txt");

                    
                    foreach (string sor in sorok)
                    {
                        string[] adatok = sor.Split(' '); 

                        if (adatok.Length >= 5)
                        {
                            telekLista.Add(new Telek(adatok[0], adatok[1], adatok[2], int.Parse(adatok[3]), adatok[4]));
                        }
                    }

                    
                    int telekSzam = telekLista.Count;
                    Console.WriteLine($": Az állományban {telekSzam} telek adatai vannak.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Hiba történt az állomány olvasása közben: {ex.Message}");
                }

               
                Console.Write(": Kérem, adja meg a tulajdonos adószámát: ");
                string adoszam = Console.ReadLine();

               
                Telek keresettTelek = telekLista.FirstOrDefault(t => t.Adoszam == adoszam);

                
                if (keresettTelek != null)
                {
                    Console.WriteLine($"A megadott adószámmal rendelkező tulajdonos az {keresettTelek.Utca} utcában, {keresettTelek.Hazszam}. házszám alatt lakik.");
                }
                else
                {
                    Console.WriteLine("Nem szerepel az adatállományban.");
                }

                Console.ReadLine(); 
            }
        }

    }
}

