﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace halak
{
    class Program
    {
        static void Main(string[] args)
        {


            Random random = new Random();
            int halakSzama = 14;
            double osszSuly = 0;
            double osszHossz = 0;
            int nagyobb70Kg = 0;
            int nagyobb50KgEs28Cm = 0;
            bool van2KgNalNagyobbHal = false;

            for (int i = 0; i < halakSzama; i++)
            {
                halak hal = new Hal();
                hal.Suly = random.Next(1, 101);
                hal.Hossz = random.Next(10, 101);

                osszSuly += hal.Suly;
                osszHossz += hal.Hossz;

                if (hal.Suly > 70)
                {
                    nagyobb70Kg++;
                }

                if (hal.Suly > 50 && hal.Hossz > 28)
                {
                    nagyobb50KgEs28Cm++;
                }

                if (hal.Suly > 2)
                {
                    van2KgNalNagyobbHal = true;
                }
            }

            double atlagHossz = osszHossz / halakSzama;

            Console.WriteLine($"Az össz súly: {osszSuly} kg");
            Console.WriteLine($"Az átlagos hossz: {atlagHossz} cm");
            Console.WriteLine($"Halak száma 70 kg-nál nagyobb: {nagyobb70Kg}");
            Console.WriteLine($"Halak száma 50 kg-nál nagyobb és 28 cm-nél hosszabb: {nagyobb50KgEs28Cm}");

            if (van2KgNalNagyobbHal)
            {
                Console.WriteLine("Van 2 kg-nál nagyobb hal a csoportban.");
            }
            else
            {
                Console.WriteLine("Nincs 2 kg-nál nagyobb hal a csoportban.");
            }
        }
    }
    Console.Readkey();
}
    



