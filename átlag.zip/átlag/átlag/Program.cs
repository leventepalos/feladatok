﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace átlag
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                int szamokSzama = 10; 
                double[] szamTomb = new double[szamokSzama]; 
                
                double osszeg = 0;
                for (int i = 0; i < szamokSzama; i++)
                {
                    Console.Write("Kérem adja meg a(z) " + (i + 1) + ". számot: ");

                    szamTomb[i] = Convert.ToDouble(Console.ReadLine());

                    osszeg += szamTomb[i];
                }

                double atlag = osszeg / szamokSzama;

                Console.WriteLine("A megadott számok átlaga: " + atlag);

                Console.ReadKey();
            }
        }
    }
}
