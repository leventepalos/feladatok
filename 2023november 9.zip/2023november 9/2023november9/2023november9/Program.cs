﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2023november9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
                Console.Write("Adja meg a dobások számát : ");
                int N = Convert.ToInt32(Console.ReadLine());

                int anniNyert = 0;
                int panniNyert = 0;

                Random random = new Random();

                for (int i = 0; i < N; i++)
                {
                    
                    int kocka1 = random.Next(1, 7);
                    int kocka2 = random.Next(1, 7);
                    int kocka3 = random.Next(1, 7);

                   
                    int osszeg = kocka1 + kocka2 + kocka3;

                    
                    Console.WriteLine($"Dobás {i + 1}: {kocka1}, {kocka2}, {kocka3} | Összeg: {osszeg} | Nyertes: {(osszeg < 10 ? "Anni" : "Panni")}");

                    
                    if (osszeg < 10)
                    {
                        anniNyert++;
                    }
                    else
                    {
                        panniNyert++;
                    }
                }

               
                Console.WriteLine($"Anni nyert: {anniNyert} alkalommal");
                Console.WriteLine($"Panni nyert: {panniNyert} alkalommal");

            Console.ReadLine();
                 
        }
    }
}



