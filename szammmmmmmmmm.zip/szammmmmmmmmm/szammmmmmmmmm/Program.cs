﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szammmmmmmmmm
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Gondoltam egy számot 1 és 100 között! Találd ki hogy melyik számra gondoltam");
            Random véletlen = new Random();
            
            int gondoltszám = véletlen.Next(1, 101);
            Console.WriteLine("a gondolt szám a:"+gondoltszám);
           
            Console.WriteLine("Tippelj egy sazámot ");
            int tipp = Convert.ToInt32(Console.ReadLine());




            while (gondoltszám== tipp)
            {
                if ()
                  {

                  }
            }
            Console.WriteLine("grat kitaláltad ");

            Console.ReadLine();

        }
    }
}
